package com.iskconhaldia.devoteemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevoteemanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
