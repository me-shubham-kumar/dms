package com.iskconhaldia.devoteemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevoteemanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevoteemanagerApplication.class, args);
	}

}
